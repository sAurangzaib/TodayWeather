//
//  TodayWeatherTests.swift
//  TodayWeatherTests
//
//  Created by Syed M.Aurangzaib on 04/05/2021.
//

import XCTest
import CoreLocation
@testable import TodayWeather

class TodayWeatherTests: XCTestCase {
    
    func test_current_weather_with_validRequest_returns_weatherResponse() {
        
        //Arrange
        
        let latitude: Double = 31.4504
        let longitude: Double = 73.135
        let weatherEndPoint = WeatherEndPoints.currentLocation(coordinate:  CLLocationCoordinate2D(latitude: latitude, longitude: longitude))
        
        //ACT
        do {
            let request = try weatherEndPoint.asURLRequest()
            
            Request.shared.makeOpenAPIRequest(request: request, dataReturnType: CurrentWeather.self) { (response) in
                switch response {
                    case .success(let weather):
                        //Asserts
                        XCTAssertNotNil(weather)
                        
                        if let weatherModel = weather as? CurrentWeather {
                            XCTAssertEqual(weatherModel.cod, 200)
                            XCTAssertEqual(weatherModel.coord?.lat, latitude)
                            XCTAssertEqual(weatherModel.coord?.lon, longitude)
                            
                        }
                        break
                    case .failure:
                        break
                }
            }
            
        } catch {
        }
    }
    
    func test_current_weather_with_invalidRequest_returns_errorResponse() {
        
        //Arrange
        let weatherEndPoint = WeatherEndPoints.currentLocation(coordinate: nil)
        
        //ACT
        do {
            let request = try weatherEndPoint.asURLRequest()
            
            Request.shared.makeOpenAPIRequest(request: request, dataReturnType: CurrentWeather.self) { (response) in
                switch response {
                    case .success:
                        break
                    case .failure(let error):
                        //Asserts
                        XCTAssertNotNil(error)
                        XCTAssertNotNil(error.errorDescription)
                }
            }
            
        } catch (let error){
            let apiError = APIError.internalFailed(reason: error)
            //Asserts
            XCTAssertNotNil(apiError)
            XCTAssertNotNil(apiError.errorDescription)
        }
    }
}
