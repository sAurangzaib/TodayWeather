//
//  OpenAPIRespons.swift
//  TodayWeather
//
//  Created by Syed M.Aurangzaib on 05/05/2021.
//

import Foundation

typealias OpenAPIDecodable = Decodable & GoogleResponseDecodable

protocol GoogleResponseDecodable {
    var cod: Int? { get set }
}
