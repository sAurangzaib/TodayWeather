//
//  APIProvider.swift
//  TodayWeather
//
//  Created by Syed M.Aurangzaib on 05/05/2021.
//

import UIKit
import Alamofire
import CoreLocation

protocol APIConfiguration: URLRequestConvertible {
    var method: HTTPMethod { get }
    var path: String { get }
    var parameters: Parameters? { get }
}

enum ContentType: String {
    case json = "application/json"
}



enum WeatherEndPoints: APIConfiguration {
    //Google Map
    case currentLocation(coordinate: CLLocationCoordinate2D?)
    
    // MARK: HTTPMethod
    var method: HTTPMethod {
        switch self {
        case .currentLocation:
            return .get
        }
    }
    
    // MARK: Path
    var path: String {
        switch self {
        case .currentLocation:
            return "/weather"
        }
    }
    
    // MARK: Parameters
    var parameters: Parameters? {
        switch self {
            
        case .currentLocation(let coordinate):
            
            var params: [String: Any] = [:]
            
            params["appid"]     = apiKey
            params["lat"]       = coordinate?.latitude
            params["lon"]       = coordinate?.longitude
            
            return params
            
        }
    }
    
    // MARK: URLRequestConvertible
    func asURLRequest() throws -> URLRequest {
        
        let url = try baseURL.asURL()
        
        var urlRequest = URLRequest(url: url.appendingPathComponent(path))
        
        // HTTP Method
        urlRequest.httpMethod = method.rawValue
        
        
        // Parameters
        if let parameters = parameters {
            do {
                debugPrint("--------- Request --------")
                debugPrint("URL: \(url.appendingPathComponent(path))")
                debugPrint("Parmas: \(parameters)")
                debugPrint("Type: \(method.rawValue)")
                debugPrint("--------------------------")
                if method.rawValue != "GET" {
                    urlRequest = try JSONEncoding.default.encode(urlRequest, with: parameters)
                    //                    urlRequest.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: [])
                } else {
                    urlRequest = try URLEncoding.default.encode(urlRequest, with: parameters)
                }
            } catch {
                throw AFError.parameterEncodingFailed(reason: .jsonEncodingFailed(error: error))
            }
        }
        return urlRequest
    }
}
