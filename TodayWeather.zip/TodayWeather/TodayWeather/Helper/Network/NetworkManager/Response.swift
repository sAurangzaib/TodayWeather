//
//  Response.swift
//  TodayWeather
//
//  Created by Syed M.Aurangzaib on 05/05/2021.
//

import Foundation

enum APIResponse<T> {
    case success(T)
    case failure(APIError)
}
