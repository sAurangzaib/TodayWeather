//
//  Request.swift
//  TodayWeather
//
//  Created by Syed M.Aurangzaib on 05/05/2021.
//

import Foundation

import Alamofire


class Request {
    
    static let shared = Request()
    private init() {}
    
    func makeOpenAPIRequest<T: OpenAPIDecodable>(request: URLRequest, dataReturnType: T.Type, completionHandler: @escaping (APIResponse<Any?>) -> Void) {
        
        AF.request(request)
            .validate(statusCode: 200..<300)
            .responseData {(response) in
                switch response.result {
                    case .success(let value):
                        do {
                            debugPrint("----- Json Response -----")
                            debugPrint(value.prettyPrintedJSONString ?? "")
                            debugPrint("-------------------------")
                            
                            let result = try JSONDecoder().decode(T.self, from: value)
                            if result.cod == 200 {
                                completionHandler(APIResponse.success(result))
                            } else {
                                completionHandler(APIResponse.failure(APIError.parseFailed(reason:
                                                                                                    ParseFailureReason(code: 400, message: "Something went wrong"))))
                            }
                        } catch let error {
                            completionHandler(APIResponse.failure(APIError.internalFailed(reason: error)))
                        }
                    case .failure(let error):
                        completionHandler(APIResponse.failure(APIError.internalFailed(reason: error)))
                }
            }
    }
}
