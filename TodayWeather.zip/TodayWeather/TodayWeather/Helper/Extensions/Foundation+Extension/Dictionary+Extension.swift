//
//  Dictionary+Extension.swift
//  TodayWeather
//
//  Created by Syed M.Aurangzaib on 02/05/2021.
//

import Foundation
extension Dictionary where Key == String {
    mutating func set(_ value: Value?, for key: DictionaryKey) {
        self[key.rawValue] = value
    }
    
    func string(for key: DictionaryKey) -> String? {
        return self[key.rawValue] as? String
    }
    
    func int(for key: DictionaryKey) -> Int? {
        return self[key.rawValue] as? Int
    }
    
    func bool(for key: DictionaryKey) -> Bool? {
        return self[key.rawValue] as? Bool
    }
}

enum DictionaryKey: String {
    case lat
    case lon
    case appid
}
