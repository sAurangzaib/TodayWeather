//
//  UIViewController+Extension.swift
//  TodayWeather
//
//  Created by Syed M.Aurangzaib on 03/05/2021.
//

import UIKit

extension UIViewController {
    func showAlert(title: String , message: String, completion: ((UIAlertAction?) -> Void)? = nil) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default, handler: completion)
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }
}
