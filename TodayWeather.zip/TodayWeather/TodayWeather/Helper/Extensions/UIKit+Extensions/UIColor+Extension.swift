//
//  UIColor+Extension.swift
//  TodayWeather
//
//  Created by Syed M.Aurangzaib on 02/05/2021.
//

import UIKit

extension UIColor {
    
    static let blueTopColor = UIColor(red: 95.0/255.0, green: 165.0/255.0, blue: 1.0, alpha: 1.0)
    static let blueBottomColor = UIColor(red: 72.0/255.0, green: 114.0/255.0, blue: 184.0/255.0, alpha: 1.0)
    static let greyTopColor = UIColor(red: 151.0/255.0, green: 151.0/255.0, blue: 151.0/255.0, alpha: 1.0)
    static let greyBottomColor = UIColor(red: 72.0/255.0, green: 72.0/255.0, blue: 72.0/255.0, alpha: 1.0)

}
