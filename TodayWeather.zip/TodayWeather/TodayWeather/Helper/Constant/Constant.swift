//
//  Constant.swift
//  TodayWeather
//
//  Created by Syed M.Aurangzaib on 02/05/2021.
//

import Foundation

let baseURL = "http://api.openweathermap.org/data/2.5"
let apiKey = "d0591b06d4ae51ca736b7a451a37f510"
