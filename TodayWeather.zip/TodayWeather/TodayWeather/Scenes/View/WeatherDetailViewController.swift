//
//  WeatherDetailViewController.swift
//  TodayWeather
//
//  Created by Syed M.Aurangzaib on 30/04/2021.
//

import UIKit
import NVActivityIndicatorView
import CoreLocation

class WeatherDetailViewController: UIViewController {
    
    //MARK: IBOutlets
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var dayLabel: UILabel!
    
    @IBOutlet weak var conditionImageView: UIImageView!
    @IBOutlet weak var conditionLabel: UILabel!
    
    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var temperatureSymbolLabel: UILabel!
    @IBOutlet weak var backgroundView: UIView!
    
    
    //MARK: Properties
    private let gradientLayer = CAGradientLayer()
    private var activityIndicator: NVActivityIndicatorView!
    private let locationManager = CLLocationManager()
    private var viewModel: WeatherDetailViewModel?
    private var isBlueGradient: Bool = true
    
    //MARK: View Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.viewInit()
        self.viewSetup()
        viewModel = WeatherDetailViewModel()
        responseObjectBinding()
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        
        coordinator.animate(alongsideTransition: { (UIViewControllerTransitionCoordinatorContext) -> Void in
        }, completion: { (UIViewControllerTransitionCoordinatorContext) -> Void in
            
            if self.isBlueGradient {
                self.setBlueGradientBackground()
            } else {
                self.setGreyGradientBackground()
            }
        })
        super.viewWillTransition(to: size, with: coordinator)
    }
    
}

//MARK: - Helper methods

private extension WeatherDetailViewController {
    
    private func viewInit() {
        locationLabel.text = ""
        conditionImageView.image = nil
        conditionLabel.text = ""
        temperatureLabel.text = ""
        dayLabel.text = ""
        temperatureSymbolLabel.text = ""
    }
    
    private func viewSetup() {
        backgroundView.layer.addSublayer(gradientLayer)
        
        let indicatorSize: CGFloat = 70
        let indicatorFrame = CGRect(x: (view.frame.width-indicatorSize)/2, y: (view.frame.height-indicatorSize)/2, width: indicatorSize, height: indicatorSize)
        activityIndicator = NVActivityIndicatorView(frame: indicatorFrame, type: .lineScale, color: UIColor.white, padding: 20.0)
        activityIndicator.backgroundColor = UIColor.black
        view.addSubview(activityIndicator)
        
        locationManager.requestWhenInUseAuthorization()
        
        activityIndicator.startAnimating()
        if (CLLocationManager.locationServicesEnabled()) {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.startUpdatingLocation()
        }
    }
    
    private func setBlueGradientBackground(){
        let topColor = UIColor.blueTopColor.cgColor
        let bottomColor = UIColor.blueBottomColor.cgColor
        gradientLayer.frame = view.bounds
        gradientLayer.colors = [topColor, bottomColor]
    }
    
    private func setGreyGradientBackground(){
        let topColor = UIColor.greyTopColor.cgColor
        let bottomColor = UIColor.greyBottomColor.cgColor
        gradientLayer.frame = view.bounds
        gradientLayer.colors = [topColor, bottomColor]
    }
    
    private func responseObjectBinding() {
        
        //First check if API returns error
        viewModel?.appErrorBoxedModel.bind(listener: { [unowned self] (error) in
            self.activityIndicator.stopAnimating()
            if error != nil {
                self.showAlert(title: "Error", message: error?.localizedDescription ?? "Something went wrong")
                return
            }
        })
        
        viewModel?.weatherBoxedModel.bind(listener: { [unowned self] (weather) in
            
            self.activityIndicator.stopAnimating()
            guard let model = weather else { return }
            self.locationLabel.text = model.name
            if let firstObj = model.weather?.first {
                if let image = firstObj.icon {
                    self.conditionImageView.image = UIImage(named: image)
                }
                self.conditionLabel.text = firstObj.main
                
                let suffix = firstObj.icon?.suffix(1)
                if(suffix == "n"){
                    self.isBlueGradient = false
                    self.setGreyGradientBackground()
                }else{
                    self.isBlueGradient = true
                    self.setBlueGradientBackground()
                }
            }
            if let celsiusTemp = model.main?.temp {
                self.temperatureLabel.text = String(format: "%.0f", celsiusTemp)
                self.temperatureSymbolLabel.text = "℃"
            }
            self.dayLabel.text = self.viewModel?.currentDay
        })
    }
}

extension WeatherDetailViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations[0]
        viewModel?.locationCoordinate = location.coordinate
        locationManager.stopUpdatingLocation()
        viewModel?.weatherData()
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {        
        self.showAlert(title: "Error", message: error.localizedDescription)
        activityIndicator.stopAnimating()
    }
}
