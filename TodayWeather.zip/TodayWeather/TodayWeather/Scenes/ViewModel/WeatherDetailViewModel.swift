//
//  WeatherDetailViewModel.swift
//  TodayWeather
//
//  Created by Syed M.Aurangzaib on 02/05/2021.
//

import Foundation
import CoreLocation

class WeatherDetailViewModel {
    
    //MARK: Properties
    var locationCoordinate: CLLocationCoordinate2D!
    
    var weatherBoxedModel: BoxListener<CurrentWeather?> = BoxListener(nil)
    var appErrorBoxedModel: BoxListener<APIError?> = BoxListener(nil)
    
    
    var currentDay: String {
        let date = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEEE"
        return dateFormatter.string(from: date)
    }
    
}

//MARK: - Network Methods

extension WeatherDetailViewModel {
        
    func weatherData() {

        let weatherEndPoint = WeatherEndPoints.currentLocation(coordinate: locationCoordinate)
        
        do {
            let request = try weatherEndPoint.asURLRequest()
            
            Request.shared.makeOpenAPIRequest(request: request, dataReturnType: CurrentWeather.self) { (response) in
                switch response {
                    case .success(let weather):
                        if let weatherModel = weather as? CurrentWeather {
                            self.weatherBoxedModel.value = weatherModel
                        }
                    case .failure(let error):
                        self.appErrorBoxedModel.value = error
                }
            }
            
        } catch (let error){
            let apiError = APIError.internalFailed(reason: error)
            self.appErrorBoxedModel.value = apiError
        }
    }
}
