//
//  WeatherDataModel.swift
//  TodayWeather
//
//  Created by Syed M.Aurangzaib on 02/05/2021.
//

import UIKit

struct WeatherRequestData {
    var latitude: Double
    var longitude: Double
}
